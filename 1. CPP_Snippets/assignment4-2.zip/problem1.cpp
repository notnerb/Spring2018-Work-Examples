
#include <stdlib.h>
#include <string>
#include <iostream>

// Node structure.
struct tnode {
               // The data in this node.
              struct tnode *left = NULL;   // Pointer to the left subtree.
              struct tnode *right = NULL;  // Pointer to the right subtree.
              public:
              std::string data;
              int leftn;
              int rightn;
              tnode();
              tnode(int eft, int ight, std::string name);
              tnode(std::string name);
            
		  
};
//need constructor.
tnode::tnode(){
	left = NULL;
	right = NULL;		  
}
tnode::tnode(int eft, int ight, std::string name){
	leftn = eft;
	rightn = ight;
	data =  name;
	
}
tnode::tnode(std::string name){
	data = name;
}

class tree
{
	
	public:
		tnode *stitcher;
        tnode *root;
};
void prePrint( tnode *root ) {
           // Print all the items in the tree to which root points.
           // root then left then right.
        if ( root!= NULL ) { 
			//Print the root item
           std::cout << root->data << " "; 
               
		   prePrint(root->left);    // Print left subtree
           prePrint( root->right );   // Print right subtree
        }
}
void postPrint( tnode *root ) {
           // Print all the items in the tree to which root points.
           // left then right then root
        if ( root != NULL ) {  
           postPrint(root->left );    
           postPrint(root->right );   
           std::cout <<root->data << " ";       
        }
}


tnode *construct(tnode ref2[], int numNod){
	
	for(int i = 0; i<numNod; i++){
		if(ref2[i].leftn!= -1){
		ref2[i].left = &(ref2[ref2[i].leftn]);
	
		}
		if(ref2[i].rightn!= -1){
		ref2[i].right = &(ref2[ref2[i].rightn]);
		}
		
	}
	return ref2;
}
void inPrint( tnode *root ) {
          
        if ( root != NULL ) {  
           inPrint(root->left);    // Print  left subtree.
           std::cout << root->data << " ";     // root item.
           inPrint(root->right);   // Print right subtree
        }
 }




int main(){
	int numNodes;
	//cin number on nodes
	std::cin>>numNodes;
	tnode mapo[numNodes];
	int inleft;
	int inright;
	std::string name;
	for(int i = 0; i<numNodes; i++){
		//build array with tnodes, to be stitched into a tree.
		//do this for speed, array access is fast.
		std::cin>>name;
		std::cin>>inleft;
		std::cin>>inright;
		mapo[i] = tnode(inleft, inright, name);
		//std::cout<<"\n"<<mapo[i].data<<" "<<mapo[i].leftn;
		//using the array of tnodes, look at the leftn and rightn values of each node,
		//set the pointers, referencing the order of each node in the array.
		//std::cout<<mapo[8].data;
	}
	//intiliaze and populate
	tnode* yay = construct(mapo, numNodes);
	//std::cout<<life.root->data;

	//print
	postPrint(yay);
	std::cout<<"\n";
	inPrint(yay);
	std::cout<<"\n";
	prePrint(yay);
}


#include <stdlib.h>
#include <string>
#include <iostream>


// Node structure.
struct tnode {
                       // The data in this node.
              struct tnode *left = NULL;   // Pointer to the left subtree.
              struct tnode *right = NULL;  // Pointer to the right subtree.
              public:
              std::string data;
              int leftn;
              int rightn;
              tnode();
              tnode(int eft, int ight, std::string name);
              tnode(std::string name);
           
		  
};
//need constructor.
tnode::tnode(){
	left = NULL;
	right = NULL;		  
}
tnode::tnode(int eft, int ight, std::string name){
	leftn = eft;
	rightn = ight;
	data =  name;
	
}
tnode::tnode(std::string name){
	data = name;
}
class tree
{
	
	public:
	
        
       
        tnode *stitcher;
        tnode *root;
};

 int height(tnode *node)
{
    if (node==NULL)
        return 0;
    else
    {
        /* compute the height of each subtree */
        int lheight = height(node->left);
        int rheight = height(node->right);
 
        /* use the larger one */
        if (lheight > rheight)
            return(lheight+1);
        else return(rheight+1);
    }
}

tnode *construct( tnode ref2[], int numNod){
	
	for(int i = 0; i<numNod; i++){
		if(ref2[i].leftn!= -1){
		ref2[i].left = &(ref2[ref2[i].leftn]);
	
		}
		if(ref2[i].rightn!= -1){
		ref2[i].right = &(ref2[ref2[i].rightn]);
		}
		
	}
	return ref2;
}
//initial copypasta
/* Print nodes at a given level */
void printlevel(tnode *root, int level)
{
    if (root == NULL)
        return;
    if (level == 1)
        std::cout<<root->data<<" ";
    else if (level > 1)
    {
        printlevel(root->left, level-1);
        printlevel(root->right, level-1);
    }
}
void printLvlo(tnode *root)
{
    int h = height(root);
    int i;
    for (i=1; i<=h; i++)
        printlevel(root, i);
}
 





int main(){
	int numNodes;
	//cin number on nodes
	std::cin>>numNodes;
	
	tnode mapo[numNodes];
	int inleft;
	int inright;
	std::string name;
	for(int i = 0; i<numNodes; i++){
		//build array with tnodes, to be stitched into a tree.
		//do this for speed, array access is fast.
		std::cin>>name;
		std::cin>>inleft;
		std::cin>>inright;
		mapo[i] = tnode(inleft, inright, name);
		//std::cout<<"\n"<<mapo[i].data<<" "<<mapo[i].leftn;
		//using the array of tnodes, look at the leftn and rightn values of each node,
		//set the pointers, referencing the order of each node in the array.
		//std::cout<<mapo[8].data;
	}
	//intiliaze tree
	tnode *x = construct(mapo, numNodes);
	//std::cout<<life.root->data;
	
	//populate
	//build tree
	//std::cout<<"\n"<< height(&mapo[0]);
	printLvlo(x);
}


#include <stdlib.h>
#include <string>
#include <iostream>


// Node structure.
struct tnode {
                       // The data in this node.
              struct tnode *left = NULL;   // Pointer to the left subtree.
              struct tnode *right = NULL;  // Pointer to the right subtree.
              public:
              std::string data;
              int leftn;
              int rightn;
              tnode();
              tnode(int eft, int ight, std::string name);
              tnode(std::string name);
           
};
//need constructor.
tnode::tnode(){
	left = NULL;
	right = NULL;		  
}
tnode::tnode(int eft, int ight, std::string name){
	leftn = eft;
	rightn = ight;
	data =  name;
	
}
tnode::tnode(std::string name){
	data = name;
}
class tree
{
	
	public:
	
	tree();
	tnode *conTree(std::string in[], std::string post[], int inst, int inlst, int pst, int plst);
	int pindex = 0;
    tnode *stitcher;
    tnode *root;   
};
tree::tree(){

}

int getInIndex(std::string in[], int st, int end, std::string data){
	for(int i = st; i <= end; i++){
			if(in[i] == data){
				return i;
			}
	}
	return -1;
}
tnode *tree::conTree(std::string in[], std::string post[], int inst, int inlst, int pst, int plst){
	if(inst > inlst || plst > plst){
		return NULL;
	}
	std::string rootVal = post[plst];
	tnode *root = new tnode(rootVal);
	pindex++;
	if(inst == inlst){
		return root;
	}
	int index = getInIndex(in, inst, inlst, root->data);
	root->left = conTree(in, post, inst, index-1, pst, pst + index -(inst+1));
	root->right = conTree(in, post, index+1, inlst, pst+index - inst, plst-1);
	return root;
}
int height(tnode *node)
{
    if (node==NULL)
        return 0;
    else
    {
        /* compute the height of each subtree */
        int lheight = height(node->left);
        int rheight = height(node->right);
 
        /* use the larger one */
        if (lheight > rheight)
            return(lheight+1);
        else return(rheight+1);
    }
}
/* Print nodes at a given level */
void printlevel(tnode *root, int level)
{
    if (root == NULL)
        return;
    if (level == 1)
        std::cout<<root->data<<" ";
    else if (level > 1)
    {
        printlevel(root->left, level-1);
        printlevel(root->right, level-1);
    }
}
void printLevelO(tnode *root)
{
    int h = height(root);
    int i;
    for (i=1; i<=h; i++)
        printlevel(root, i);
}
 
int main(){
	int numNodes;
	//cin number on nodes
	std::cin>>numNodes;
	std::string inorder[numNodes];
	std::string postorder[numNodes];
	
	std::string name;
	//build inorder list
	for(int i = 0; i<numNodes; i++){
		//build array with tnodes, to be stitched into a tree.
		//do this for speed, array access is fast.
		std::cin>>name;
		
		postorder[i] = name;
		//std::cout<<"\n"<<mapo[i].data<<" "<<mapo[i].leftn;
		//using the array of tnodes, look at the leftn and rightn values of each node,
		//set the pointers, referencing the order of each node in the array.
		//std::cout<<mapo[8].data;
	}
	//build postorder list.
	for(int i = 0; i<numNodes; i++){
		//build array with tnodes, to be stitched into a tree.
		//do this for speed, array access is fast.
		std::cin>>name;
		
		inorder[i] = name;
	}
	tree *t  = new tree();
	tnode *res = t->conTree(inorder, postorder, 0, numNodes - 1, 0, numNodes-1);
	
	printLevelO(res);
}

